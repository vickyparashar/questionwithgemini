# questionwithgemini
This Project will give answer of current screen question displaying on window
